关键词：年度总初级生产力、MODIS/061/MOD17A2H、Terra MODIS、Gpp、gross primary productivity

## 1. 适用场景与输入要求

500 m，8 天合成产品。传入完整日历年，返回全年累计总初级生产力及有效合成期数。运行环境为已初始化的 earthengine-api。

## 2. 核心公式与参数避坑

Gpp × 0.0001，输出单位为 kg C/m²。每期 Gpp 已是 8 天（年末期为 5 或 6 天）累计量，年内应求和而非取均值。MOD17A2H 对云遮挡期已用气象与插补 FPAR 填补：用 Psn_QC 位 5–7（置信度 < 4）与 Gpp < 30000 排除水体、城市及填充值，避免要求全年 46 期全无云导致南方多云区整图为空；同步输出 n_good_qc 记录最佳晴空期数。 [MODIS/061/MOD17A2H](https://developers.google.com/earth-engine/datasets/catalog/MODIS_061_MOD17A2H)

## 3. 完整可运行 Python 代码

```python
import ee


def build_modis_annual_gpp(aoi: ee.Geometry, year: int) -> ee.Image:
    start_date = ee.Date.fromYMD(year, 1, 1)
    end_date = start_date.advance(1, "year")
    scenes = (ee.ImageCollection("MODIS/061/MOD17A2H")
              .filterBounds(aoi).filterDate(start_date, end_date))

    def decode(image):
        qc = image.select("Psn_QC")
        raw = image.select("Gpp")
        produced = qc.rightShift(5).bitwiseAnd(7).lt(4).And(raw.lt(30000))
        good = qc.bitwiseAnd(1).eq(0).rename("n_good_qc")
        gpp = raw.updateMask(produced).multiply(0.0001).rename("value")
        return gpp.addBands(good.updateMask(produced))

    decoded = scenes.map(decode)
    values = decoded.select("value")
    count = values.count().rename("n_obs")
    n_good = decoded.select("n_good_qc").sum().rename("n_good_qc")
    result = values.sum().updateMask(count.eq(46)).rename("modis_annual_gpp")
    return result.addBands([count, n_good]).clip(aoi)
```

## 4. 结果质检标准

陆地植被年累计量常见范围约 0–4 kg C/m²；同时核查 n_obs（完整年为 46）与 n_good_qc 评估云插补占比。
