---
name: eo-analysis-recipes
description: 执行遥感影像预处理、GEE Python 指数合成、生态水文统计与本地 GeoTIFF 分块分析时，根据传感器、指标和输出单位检索对应配方。
license: Apache-2.0
---

## 核心数据源与波段速查

| 官方数据源 | 波段与物理量 |
|---|---|
| [COPERNICUS/S2_SR_HARMONIZED](https://developers.google.com/earth-engine/datasets/catalog/COPERNICUS_S2_SR_HARMONIZED) | B3 绿、B4 红、B8 近红外（10 m）；B8A、B11、SCL（20 m）。光谱 DN / 10000。 |
| [LANDSAT/LC08/C02/T1_L2](https://developers.google.com/earth-engine/datasets/catalog/LANDSAT_LC08_C02_T1_L2) | OLI 红/近红外 SR_B4/B5；SR_B* × 0.0000275 − 0.2；ST_B10 × 0.00341802 + 149.0 K。 |
| [LANDSAT/LC09/C02/T1_L2](https://developers.google.com/earth-engine/datasets/catalog/LANDSAT_LC09_C02_T1_L2) | 与 LC08 的 C2 L2 命名和缩放一致；光学、热波段分别应用质量掩膜。 |
| [COPERNICUS/DEM/GLO30_2024_1](https://developers.google.com/earth-engine/datasets/catalog/COPERNICUS_DEM_GLO30_2024_1) | DEM 为 EGM2008 正高（m），包括植被和建筑。 |
| [COPERNICUS/S1_GRD](https://developers.google.com/earth-engine/datasets/catalog/COPERNICUS_S1_GRD) | VV/VH 为 dB，计算功率比先转线性。 |
| [ESA/WorldCover/v200](https://developers.google.com/earth-engine/datasets/catalog/ESA_WorldCover_v200) | Map 为 2021 土地覆盖类别，80 为永久水体。 |
| [MODIS/061/MOD13Q1](https://developers.google.com/earth-engine/datasets/catalog/MODIS_061_MOD13Q1) | NDVI × 0.0001，16 天。 |
| [MODIS/061/MOD11A1](https://developers.google.com/earth-engine/datasets/catalog/MODIS_061_MOD11A1) | LST_Day_1km × 0.02 K，日产品。 |
| [MODIS/061/MOD15A2H](https://developers.google.com/earth-engine/datasets/catalog/MODIS_061_MOD15A2H) | Lai_500m × 0.1；Fpar_500m × 0.01。 |
| [MODIS/061/MOD17A2H](https://developers.google.com/earth-engine/datasets/catalog/MODIS_061_MOD17A2H) | Gpp × 0.0001 kg C/m²/合成期。 |
| [NASA/GPM_L3/IMERG_V07](https://developers.google.com/earth-engine/datasets/catalog/NASA_GPM_L3_IMERG_V07) | precipitation 为 mm/h，每槽 30 分钟。 |
| [JRC/GHSL/P2023A/GHS_BUILT_S](https://developers.google.com/earth-engine/datasets/catalog/JRC_GHSL_P2023A_GHS_BUILT_S) | built_surface 为 m²/像元。 |
| [IDAHO_EPSCOR/TERRACLIMATE](https://developers.google.com/earth-engine/datasets/catalog/IDAHO_EPSCOR_TERRACLIMATE) | pr 为 mm/月，aet × 0.1 为 mm/月。 |

## 科学红线与常见翻车点

- GEE 配方由宿主完成授权和 ee.Initialize。时间区间左闭右开；调用方先确认时间窗有场景，再检查 AOI 内有效像元和各期覆盖率。
- 在服务端用 map、reduce 构建计算图。固定波段或固定模型因子的 Python 循环可用于构图；逐像元、逐景计算避免 getInfo。
- Landsat QA_PIXEL 位 0–5 全零可保守排除填充、膨胀云、卷云、云、云影和雪；结合 QA_RADSAT。早期 TM/ETM+ 须重新映射波段和热通道。
- 跨传感器比较先统一辐射基线、光谱响应、空间支持尺度和物候窗口。旧 TOA 回归系数需要按 SR 重新标定。
- 已退役集合说明：历史集合 LANDSAT/LE7_TOA_5YEAR 五年合成无等价的 C2 L2 单景替代；基于 LANDSAT/LE07/C02/T1_L2 重建同季合成时需记录有效观测数与 ETM+ 条带缺口。
- 光学合成保留质量掩膜；分类用最近邻，连续量按目标物理量选择插值、面积加权均值或总量守恒聚合。
- 统计明确 CRS 与格网。面积按 pixelArea 或合适的等面积投影计算；静态 DEM 和年度分类图按产品期次处理。
- 本地配方逐窗返回数组和位置，继承首幅或指定参考栅格的变换和 CRS。缺测用 NaN 表示，零值保留物理含义。

## references/ 配方路由

| 具体问题 | 独立配方 |
|---|---|
| 植被绿度中位数 | [s2-ndvi.md](references/s2-ndvi.md) |
| 开阔水体指数 | [s2-ndwi.md](references/s2-ndwi.md) |
| 河流水体浑浊度代理 | [s2-ndti.md](references/s2-ndti.md) |
| 冠层水分指数 | [s2-ndmi.md](references/s2-ndmi.md) |
| Landsat 地表反射率合成 | [landsat-surface-reflectance.md](references/landsat-surface-reflectance.md) |
| 晴空地表温度合成 | [landsat-surface-temperature.md](references/landsat-surface-temperature.md) |
| MODIS 时段植被指数 | [modis-ndvi.md](references/modis-ndvi.md) |
| 昼间地表温度均值 | [modis-day-lst.md](references/modis-day-lst.md) |
| 叶面积指数均值 | [modis-lai.md](references/modis-lai.md) |
| 冠层吸收光合有效辐射比例 | [modis-fpar.md](references/modis-fpar.md) |
| 年度总初级生产力 | [modis-annual-gpp.md](references/modis-annual-gpp.md) |
| 按行政区汇总地类面积 | [worldcover-class-area.md](references/worldcover-class-area.md) |
| 分层抽取地类像元 | [worldcover-stratified-sample.md](references/worldcover-stratified-sample.md) |
| 从分幅 DSM 计算坡度 | [copernicus-slope.md](references/copernicus-slope.md) |
| 栅格配对差值 | [raster-difference.md](references/raster-difference.md) |
| 土壤调节植被指数 | [raster-savi.md](references/raster-savi.md) |
| 有效观测时段均值 | [raster-mean.md](references/raster-mean.md) |
| 双侧时序插值填洞 | [raster-linear-fill.md](references/raster-linear-fill.md) |
| 逐像元线性趋势 | [raster-trend.md](references/raster-trend.md) |
| 配对时序误差 | [raster-rmse.md](references/raster-rmse.md) |
| 温度单位换算 | [raster-kelvin-to-celsius.md](references/raster-kelvin-to-celsius.md) |
| 逐像元配对相关 | [raster-pearson.md](references/raster-pearson.md) |
| 半小时降水率积分 | [imerg-rainfall.md](references/imerg-rainfall.md) |
| 月降水与实际蒸散水量差 | [terraclimate-monthly-water.md](references/terraclimate-monthly-water.md) |
| 双极化雷达植被指数 | [s1-radar-vegetation.md](references/s1-radar-vegetation.md) |
| 建成表面面积变化 | [ghsl-built-change.md](references/ghsl-built-change.md) |
| 二分像元植被覆盖度 | [fractional-vegetation.md](references/fractional-vegetation.md) |
| 同物候基准植被健康指数 | [vegetation-health.md](references/vegetation-health.md) |
| 多年平均坡面侵蚀估算 | [usle-soil-loss.md](references/usle-soil-loss.md) |
| 月尺度光能利用率模型 | [casa-monthly-npp.md](references/casa-monthly-npp.md) |
| 地形湿度指数 | [wetness-index.md](references/wetness-index.md) |
| 空间独立验证的土地覆盖分类 | [random-forest-land-cover.md](references/random-forest-land-cover.md) |
| 年序列稳健变化率 | [sen-slope.md](references/sen-slope.md) |
| 同轨 SAR 事件前后变化 | [s1-event-change.md](references/s1-event-change.md) |
| 对齐到参考栅格 | [raster-align.md](references/raster-align.md) |
| 参考范围归一化 | [raster-minmax.md](references/raster-minmax.md) |
| 保留缺测的线性去趋势 | [raster-detrend.md](references/raster-detrend.md) |
| 历史同期均值填洞 | [raster-historical-fill.md](references/raster-historical-fill.md) |
| 谐波拟合填补季节序列 | [raster-harmonic-gap-fill.md](references/raster-harmonic-gap-fill.md) |
| 局部多项式平滑时序 | [raster-savgol.md](references/raster-savgol.md) |
| 年际变异系数 | [raster-coefficient-variation.md](references/raster-coefficient-variation.md) |
| 分层地理探测器 q 统计量 | [geodetector-factor.md](references/geodetector-factor.md) |
| 汇水面积与坡度估计水流强度 | [stream-power-index.md](references/stream-power-index.md) |
