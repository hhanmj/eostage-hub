---
name: gee-practice-cards
description: "Google Earth Engine (GEE) 科研方法边界与工程落地 10 项专题知识卡：覆盖 Landsat/S2 去云方法对照与云下重建澄清、HLS 跨传感器一致化、Sentinel-1 轨道锁定与线性功率运算、合成算子语义与有效观测数诊断、12 类数据集 QA 与缩放矩阵、复杂边界切块安全边界、导出前预演路由、数据血缘台账、EECU 配额与成本控制，以及端到端任务自检。与 99 项代码配方库 `eo-analysis-recipes` 及 5 章体系手册 `gee-textbook-cookbook` 明确互补。"
license: Apache-2.0
---

# GEE 科研实践与工程避坑知识卡 (GEE Practice Cards)

本技能包沉淀 GEE 实际科研任务中最易被忽略的**方法边界、传感器一致性前提、计算图安全与可溯源交付契约**。当 `eo-analysis-recipes` 提供具体算子代码、`gee-textbook-cookbook` 提供整体方法论框架时，本技能包的 10 份专题卡负责解决**具体选型权衡、跨传感器陷阱与交付门禁**。

请按需调用 `skill_read(skill_id="gee-practice-cards", file_path=...)` 仅读取与当前问题直接匹配的卡片：

| 专题卡片 | 核心覆盖问题与适用场景 |
| --- | --- |
| `references/landsat-s2-cloud-mask-boundaries.md` | Landsat C2 `QA_PIXEL`/`QA_RADSAT` 与 `simpleCloudScore` 边界、高亮地物/积雪误判、去云与云下重建的本质区分、S2 四法控制变量对比标准 |
| `references/cross-sensor-harmonization.md` | Landsat 8/9 与 Sentinel-2 联合密度序列：NASA HLS (`HLSL30`/`HLSS30`) 窄近红外映射、同日对比解释边界与残余偏差检验 |
| `references/sentinel1-sar-method-boundaries.md` | Sentinel-1 GRD 观测模式/升降轨/相对轨道号锁定、dB 与线性功率域转换、`angle` 局部地形局限与洪水阈值候选边界 |
| `references/temporal-compositing-semantics.md` | `median`/`mean`/`mosaic`/`qualityMosaic` 语义差异、必附有效观测数 `valid_obs` 与 `source_time` 诊断、空窗口保留规程 |
| `references/multi-sensor-qa-scale-matrix.md` | S2、Landsat C2 L2、HLS、MODIS VI/LST、Dynamic World、WorldCover、S1 GRD、VIIRS 夜光、GHSL/WorldPop/建筑与 DEM 全表 QA/缩放/单位速查 |
| `references/boundary-and-tiling-guardrails.md` | 复杂 AOI 简化与粗滤/精算分离、禁用早期 `.clip()`、可独立切块（tile-safe）与禁切块（PCA/RSEI/流域/分割）算法判定 |
| `references/export-preflight-and-routing.md` | `gee_export_preflight` 预演规程、9 块自动/64 块硬上限分流、本地 GeoTIFF 与 Drive/GCS/Asset 批导选择、投影对齐与 nodata 规范 |
| `references/data-layer-provenance-ledger.md` | 官方库与社区库核验边界、废弃数据集替换记录、波段/缩放/掩膜与产物血缘十字段可复现台账 |
| `references/eecu-quota-and-cost-control.md` | EECU 计算单元与非商用三档配额（150h/1000h/100kh）、标准并发与上限常数、高耗算子排查及禁止多账号绕过红线 |
| `references/gee-workflow-review-and-routing.md` | 检索与验证门禁 -> `gee_script_inspect` 审查清单 -> 8 步最小探测排错阶梯 -> 模棱两可提取请求的先问后算路由 |

## 与 EOStage 工具链协作顺序

1. **选数与验证**：先用 `gee_catalog_search` 或 `gee_dataset_advisor` 查官方/社区目录并做多选对比；关键数据在写脚本前核实波段名、缩放系数与是否退役。
2. **可用性与预演**：执行批量计算或导出前，先后调用 `gee_check_availability` 与 `gee_export_preflight` 评估景数、像元总量、分块数与算法是否允许独立切块，切勿在参数缺失时静默退回固定坐标。
3. **审查与执行**：自定义脚本必须先经 `gee_script_inspect` 完成科学审查与静态安全校验；云端分析与拼接落盘分别走 `gee_cloud_analyze` 与 `gee_chunked_download`（受控上限 64 块，超过则转外部批量导出或改用预览分辨率确认）。
4. **配额核查**：运行前可通过 `gee_quota_status` 查看当前账户档位与本地 EECU 账本状态。
